#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int array[5];
	for(int i=0; i<5; i++)
	{
		cout<<"Enter the value "<<i+1<<" : ";
	cin>>array[i];
	}	
	cout<<"\n THe values stored in array are : ";
	for(int i=0; i<5; i++)
	{
		cout<<array[i]<<" \t ";
	}
	int no;
	cout<<"\n AND THE ODD numbers in an array are : ";
	for(int i=0; i<5; i++)
	{
			if(array[i]%2 !=0)
		{
		cout<<array[i]<<"\t ";	
		}	
	}
	
		
		return 0;
}
