#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int n,checkNo;
	cout<<"Number of elements of an array : ";
	cin>>n;
	int array[n];
    for(int i=0; i<n; i++)
    {
    	cout<<"\n Enter the value "<<i+1<<" : ";
    	cin>>array[i];
    	
	}
	cout<<"The values are ";
	for(int i=0; i<n; i++)
	{
		cout<<array[i]<<"\t ";
	}
	cout<<"Enter the No you want to check in an array";
	cin>>checkNo;
	bool found=false;
	for(int i=0; i<n; i++)
	{
		if(checkNo==array[i])
		{
			found=true;
			break;
			
		}
	}
	
		if(found){
			cout<<"YEs the value exists in an array."<<endl;
			
		}else{
			cout<<"No  this Number does not exists in an array."<<endl;
		}
	return 0;
}
