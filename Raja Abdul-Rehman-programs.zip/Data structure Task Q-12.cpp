#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int countE=0,countO=0;
	int arr1[5];
	cout<<"Enter the values you want to store in Array 1";
	for(int i=0; i<5; i++)
	{
		cout<<"\nEnter the value "<<i+1<<" : ";
		cin>> arr1[i];
	}
		cout<<"Array 1 values are : ";
for(int i=0; i<5; i++)
{
	cout<<arr1[i]<<" \t ";
}
//for counting values of even & odd values in an array.
for(int i=0; i<5; i++)
{
    	if(arr1[i]%2==0)
    	{
    		countE++;
		}else
		{
			countO++;
		}
}
cout<<"\n Numbers of Even values in an array are : "<<countE<<endl;

cout<<"Numbers of ODD values in an array are : "<<countO<<endl;
	return 0;
}
