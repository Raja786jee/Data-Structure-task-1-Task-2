// 1) C++ Program to calculate Area of Circle
#include<iostream>
using namespace std;
int main()
{
	float radius,area;
	cout<<"\nEnter Radius of Circle"<<"=";
	cin>>radius;
	area=3.141592654 *radius *radius;
	cout<<"Area of Circle with Radius  "<<radius<<" is "<<area;
	return 0; 
	
	
}
