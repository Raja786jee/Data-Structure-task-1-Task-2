#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int temp;
	int countE=0,countO=0;
	int arr1[5];
	cout<<"Enter the values you want to store in Array 1";
	for(int i=0; i<5; i++)
	{
		cout<<"\nEnter the value "<<i+1<<" : ";
		cin>> arr1[i];
	}
		cout<<"Array 1 values are : ";
for(int i=0; i<5; i++)
{
	cout<<arr1[i]<<" \t ";
}
//  PROGRAM FOR FINDING 2ND LARGEST INTEGER IN AN ARRAY **ANSWER**////
cout<<"\n THE 2ND LARGEST ELEMENT IN AN ARRAY IS  :";
for(int i=0; i<5; i++)
{
	for(int j=i+1; j<=5; j++)
	{
		if(arr1[i]<arr1[j])
		{
			temp=arr1[j];
			arr1[j]=arr1[i];
			arr1[i]=temp;
		}
	}		
}
	cout<<arr1[1]<<"\t ";
return 0;
}

