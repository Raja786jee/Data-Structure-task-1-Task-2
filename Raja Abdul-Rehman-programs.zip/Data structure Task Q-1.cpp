#include<iostream>
#include<conio.h>
using namespace std;
int main()
//A program for finding a minimum value in an array********/////
{
	int array[5];
	for(int i=0; i<5; i++){
	
   cout<<"\n Enter value"<<i+1<<" : ";
   	cin>> array [i];
}
 cout<<"Array values are : ";
for(int i=0; i<5; i++)
{
	cout<<array[i]<<" \t ";
}
//As for finding minimum value of an array we will codes as given below:
int min=array[0];
for(int i=0; i<5; i++)
{
	if(min>array[i])
	min=array[i];
}
cout<<"\n And the minimum value of an array is  : "<<min;

return 0;

}
