#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int arr1[5];
	cout<<"Enter the values you want to store in Array 1";
	for(int i=0; i<5; i++)
	{
		cout<<"\nEnter the value "<<i+1<<" : ";
		cin>> arr1[i];
	}
		cout<<"Array 1 values are : ";
for(int i=0; i<5; i++)
{
	cout<<arr1[i]<<" \t ";
}
// for seprating even & odd programs from an array
for(int i=0; i<5; i++)
{
	
	if(arr1[i]%2==0)
	{
		cout<<"\n Even  : "<<arr1[i]<<"\t";
	}
	else
	{
		cout<<"\n Odd : "<<arr1[i]<<"\t ";
	}
}

getch ();
}


