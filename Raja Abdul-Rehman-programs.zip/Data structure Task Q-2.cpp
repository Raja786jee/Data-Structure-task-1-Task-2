#include<iostream>
#include<conio.h>
using namespace std;
int main()
//A program for finding a maximum value in an array********/////
{
	int array[5];
	for(int i=0; i<5; i++){
	
   cout<<"\n Enter value"<<i+1<<" : ";
   	cin>> array [i];
}
 cout<<"Array values are : ";
for(int i=0; i<5; i++)
{
	cout<<array[i]<<" \t ";
}
//As for finding maximum value of an array we will codes as given below:
int max=array[0];
for(int i=1; i<5; i++)
{
	if(max<array[i])
	max=array[i];
}
cout<<"\n And the maximum value of an array is  : "<<max;
return 0;

}
