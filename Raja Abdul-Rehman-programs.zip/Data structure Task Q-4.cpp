#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
		int array[5];
	for(int i=0; i<5; i++){
	
   cout<<"\n Enter value"<<i+1<<" : ";
   	cin>> array [i];
}
 cout<<"Array values are : ";
for(int i=0; i<5; i++)
{
	cout<<array[i]<<" \t ";
}
int searchNum;
cout << "Enter the number to be searched: ";
  cin >> searchNum;

  int count = 0;
  for (int i = 0; i < 5; i++) {
    if (array[i] == searchNum) {
      count++;
    }
  }

  cout << "The number " << searchNum << " has appeared " << count << " times." << endl;

return 0;

}
