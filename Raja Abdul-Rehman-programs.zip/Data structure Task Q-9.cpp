#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int n;
	cout<<"Number of size of an array : ";
	cin>>n;
    int array[n];
	for(int i=0; i<n; i++)
	{
		cout<<"Enter the value "<<i+1<<" : ";
	cin>>array[i];
	}	
	cout<<"\n THe values stored in array are : /n";
	for(int i=0; i<n; i++)
	{
		cout<<array[i]<<" \t ";
	}
//	for finding a unique value in an arraY
cout<<"the unique values are: \n";
int flag;
 for(int i=0; i<n; i++)//0 sa 5
 	{
// 		flag=0
 		for(int j=0; j<n; j++)//0 sa 5
 		
 		{
	 
 			if(array[i]==array[j])
 			{
 				if(i!=j)
 				{
 					flag++;
 					continue;
				}
	 		}
	 	}
		if(flag==0)
		{
			cout<<array[i]<<"  is a unique number \n";
		}
		//if(flag!=0)
	 	
	}
return 0;
}

