#include<iostream>
using namespace std;
#include<conio.h>
int main()
{
	int arr[5];
	cout<<"Enter values for the Array";
	for(int i=0; i<5;i++)
	{
		cout<<"\nEnter Value"<<i+1<<"=";
		cin>>arr[i];
		
	}
	cout<<"Vales of Array are:";
	for(int i=0;i<5;i++)
	{
		cout<<arr[i]<<"\t";
		
	}
	//Sorting this array in ascending order 
	int temp;
	for(int i=0; i<5;i++)
	{
	for(int j=i+1;j<5;i++)
	{
		if(arr[i]>arr[j])
		{
			temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
		}
	}
}
//Finding the Maximum Difference
     cout<<"\n";
     int Max;
     int i=0,j=5-1;
     Max=arr[j]-arr[i];
     cout<<"Maximum difference is:"<<Max<<" ";

}
