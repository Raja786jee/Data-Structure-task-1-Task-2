#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int n;
	cout<<"Number of elements of an array : ";
	cin>>n;
    int array[n];
	for(int i=0; i<n; i++)
	{
		cout<<"Enter the value "<<i+1<<" : ";
	cin>>array[i];
	}	
	cout<<"\n THe values stored in array are : ";
	for(int i=0; i<5; i++)
	{
		cout<<array[i]<<" \t ";
	}
//	a program for sumup of all the int in an array
    int sum=0;
    for(int i=0; i<n; i++)
	{
    sum=sum+array[i];
	}
    cout<<"There sum is : ";
     cout<<sum;
return 0;
}
