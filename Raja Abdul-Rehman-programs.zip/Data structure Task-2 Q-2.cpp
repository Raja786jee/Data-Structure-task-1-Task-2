// 2) C++ Program to calculate Area of Square.
#include<iostream>
using namespace std;
int main()
{
	cout<<"Welcome to Program No_2";
	int side, area;
	// Taking input from user 
	cout<<"\nEnter the side of square: ";
	cin>>side;
	// Calculating the Area
	area = side * side; 
	//Showing Output  
	cout<<"Area of Square of side "<<side<<" is "<<area;
	return 0;
	
	
}
