// 3) C++ Program to calculate Area of Rectangle.
#include<iostream>
using namespace std;
int main()
{
	cout<<"Welcome to Program No_3";
	int length, width, area;
	// Taking input from user 
	cout<<"\nEnter the Length of Rectnagle: ";
	cin>>length;
	cout<<"\nEnter the Width of Rectangle: ";
	cin>>width;
	// Calculating the Area of Rectangle
	area = length * width; 
	//Showing Out5put  
	cout<<"Area of Rectangle= "<<area;
	return 0;
	
	
}
