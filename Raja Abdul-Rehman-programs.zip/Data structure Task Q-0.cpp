// a program for first 20 programs by using switch statment///
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{

	int n,number,min,max,checkNo,searchNum,count,no,flag,sum,i;
	bool found;
	cout<<"Number of size of an array : ";
	cin>>n;
    int array[n];
 	for(int i=0; i<n; i++)
	{
		cout<<"Enter the value "<<i+1<<" : ";
	cin>>array[i];
	}	
	cout<<"\n THe values stored in array are : \n ";
	for(int i=0; i<n; i++)
	{
		cout<<array[i]<<" \t ";
	}
	label:
	cout<<"\n {********************************************************}";	
	cout<<"\n        [Enter the program number from 1 to 9 : ]";
	cout<<"\n {********************************************************}";
	
	cin>>number;
 switch(number)
 {
 	case 1:
 	min=array[0];
for(int i=0; i<5; i++)
{
	if(min>array[i])
	min=array[i];
}
cout<<"\n And the minimum value of an array is  : "<<min;
 break;
 
 case 2:
 	max=array[0];
for(int i=1; i<5; i++)
{
	if(max<array[i])
	max=array[i];
}
cout<<"\n And the maximum value of an array is  : "<<max;
break;

case 3:
	cout<<"Enter the No you want to check in an array";
	cin>>checkNo;
	 found=false;
	for(int i=0; i<n; i++)
	{
		if(checkNo==array[i])
		{
			found=true;
		 cout<<"yes";
		}
	    else{
			cout<<"No it doesnot exist";
			}
	}
	
	break;
   case 4:
cout <<"Enter the number to be searched: ";
  count = 0;
  for (int i = 0; i < 5; i++) {
    if (array[i] == searchNum) 
	{
      count++;
    }
  }

  cout << " The number " << searchNum << " has appeared " << count << " times." << endl;
  break;
  case 5:
  
	int no;
	cout<<"\n AND THE ODD numbers in an array are : ";
	for(int i=0; i<5; i++)
	{
			if(array[i]%2 !=0)
		{
		cout<<array[i]<<"\t ";	
		}	
	}
	break;
	case 6:
	no;
	cout<<"\n AND THE Even numbers in an array are : ";
	for(int i=0; i<5; i++)
	{
			if(array[i]%2 ==0)
		{
		cout<<array[i]<<"\t ";	
		}
	}
	break;
	case 7:
	sum=0;
    for(int i=0; i<n; i++)
	{
    sum=sum+array[i];
	}
    cout<<"There sum is : ";
     cout<<sum;
	 break ;
	 case 8:
	 cout<<"\n REVERSE VALUES STORED IN AN ARRAY ARE : "<<endl;
    for(int i=n; i>=0; i--)
    {
    	cout<<array[i]<<"\n ";
	}
	break ;
case 9:
		cout<<"the unique values are: \n";
    flag;
 for(i=0; i<n; i++)
 	{
        flag=0;
 		for(int j=0; j<n; j++)
 		
 		{
	 
 			if(array[i]==array[j])
 			{
 				if(i!=j)
 				{
 					flag++;
 					continue;
				}
	 		}
	 		
	 	}
	 		if(flag==0)
		{
			cout<<array[i]<<"\n";
		}
	
		break;		
       default:
 	cout<<"invalid Number";
   }
   goto label;
 getch();
  }}
